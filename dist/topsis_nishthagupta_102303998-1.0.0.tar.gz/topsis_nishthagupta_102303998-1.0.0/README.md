# TOPSIS-NishthaGupta-102303998

A Python package to implement the Topsis technique.

## Installation
```bash
pip install Topsis-NishthaGupta-102303998